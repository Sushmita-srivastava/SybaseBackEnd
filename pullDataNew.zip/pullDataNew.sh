arg1=$1
run_id=$2
extraction_mode=$3

feed_name=`echo "$arg1" | cut -d'~' -f1`
feed_type=`echo "$arg1" | cut -d'~' -f2`

if [ "${extraction_mode,,}" = "c" ]
then
   sh /home/juniper/scripts/Extraction_w_c.sh $feed_name $run_id
else
   if [ "${feed_type,,}" = "oracle" ]
   then
      echo "Oracle system"
       java -cp /home/juniper/scripts/jars/oracle/JuniperOnPremExtractOraToStg-0.0.1-SNAPSHOT.jar com.iig.gcp.extraction.oracle.extract.App $feed_name $run_id /home/juniper/scripts/jars/oracle/config.properties
	   
	   
   elif ["$feed_type,," = "sybase"]
   then
	  echo "Sybase System"
	  java -cp /home/juniper/scripts/jars/oracle/JuniperOnPremExtractSybaseToStg-0.0.1-SNAPSHOT.jar com.iig.gcp.extraction.sybase.extract.App $feed_name $run_id /home/juniper/scripts/jars/sybase/config.properties
	   
	   
   elif [ "${feed_type,,}" = "mssql" ]
   then
      echo "MSSQL System"
      java -cp /home/juniper/scripts/jars/mssql/JuniperOnPremExtractMsSqlToStg-0.0.1-SNAPSHOT.jar com.iig.gcp.extraction.mssql.application.App $feed_name $run_id
   elif [ "${feed_type,,}" = "unix" ]
   then 
      echo "Unix System"
      java -cp /home/juniper/scripts/jars/unix/JuniperOnPremExtractFileToStg-0.0.1-SNAPSHOT.jar com.iig.gcp.extraction.fileread.application.App $feed_name $run_id /home/juniper/scripts/jars/unix/config.properties
   elif [ "${feed_type,,}" = "hive" ]
   then
      sh /home/nifi/scripts/HivetoOra/HivetoOra.sh $feed_name $run_id
 
   elif [ "${feed_type,,}" = "db2" ]
   then
      java -cp /home/juniper/scripts/jars/db2/JuniperOnPremExtractDb2ToStg-0.0.1-SNAPSHOT.jar com.iig.gcp.extraction.ibmdb2.extract.App $feed_name $run_id 
   else
      echo "Invalid System"
   fi
fi

java -cp /home/juniper/scripts/jars/nifi/NifiJobStatus-0.0.1-SNAPSHOT.jar com.infy.gcp.NifiJobStatus.JobStatusCheck $feed_name $run_id "R" "null"
status=`cat /home/juniper/scripts/jars/nifi/${feed_name}_${run_id}_R.txt`
rm -f /home/juniper/scripts/jars/nifi/${feed_name}_${run_id}_R.txt
if [ "${status,,}" = "success" ]
then
    echo "Job successfully executed"
    exit 0
else
    echo "Job Failed"
    exit 1
fi

